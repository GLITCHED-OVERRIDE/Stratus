self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open("hk-launcher-v1").then((cache) => {
      return cache.addAll([
        "./",
        "./index.html",
        "./manifest.json",
        "./install.js",
        "./icon.png"
      ]);
    })
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Allow Unity CDN requests (do NOT cache)
  if (url.origin.includes("cdn.jsdelivr.net")) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Offline-first for launcher files
  event.respondWith(
    caches.match(event.request).then((cached) => {
      return cached || fetch(event.request);
    })
  );
});